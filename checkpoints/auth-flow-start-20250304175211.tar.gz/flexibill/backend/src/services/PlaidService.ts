import { Configuration, PlaidApi, PlaidEnvironments, Products, CountryCode } from 'plaid';
import { Transaction } from '../entities/transaction.entity';
import { Account } from '../entities/account.entity';
import { DatabaseService } from '../db/DatabaseService';
import { v4 as uuidv4 } from 'uuid';

interface PlaidTransaction {
  transaction_id: string;
  amount: number;
  date: string;
  name?: string;
  merchant_name: string | undefined;
  category?: string[];
  category_id?: string;
  pending: boolean;
  payment_channel: 'online' | 'in store' | 'other';
  location?: {
    address?: string;
    city?: string;
    region?: string;
    postal_code?: string;
    country?: string;
    lat?: number;
    lon?: number;
  };
}

interface PlaidRemovedTransaction {
  transaction_id: string;
}

class PlaidService {
  private plaidClient: PlaidApi;
  private db: DatabaseService;

  constructor(
    private plaidClientId: string,
    private plaidSecret: string,
    private plaidEnvironment: 'sandbox' | 'development' | 'production' = 'sandbox'
  ) {
    const configuration = new Configuration({
      basePath: PlaidEnvironments[this.plaidEnvironment],
      baseOptions: {
        headers: {
          'PLAID-CLIENT-ID': this.plaidClientId,
          'PLAID-SECRET': this.plaidSecret,
        },
      },
    });

    this.plaidClient = new PlaidApi(configuration);
    this.db = DatabaseService.getInstance();
  }

  async createLinkToken(userId: string): Promise<string> {
    try {
      const response = await this.plaidClient.linkTokenCreate({
        user: {
          client_user_id: userId,
        },
        client_name: 'FlexiBill',
        products: [Products.Auth, Products.Transactions, Products.Balance],
        country_codes: [CountryCode.Us],
        language: 'en',
        webhook: process.env.PLAID_WEBHOOK_URL,
      });

      return response.data.link_token;
    } catch (error) {
      console.error('Error creating Plaid link token:', error);
      throw new Error('Failed to create Plaid link token');
    }
  }

  async exchangePublicToken(publicToken: string, userId: string): Promise<Account> {
    try {
      const exchangeResponse = await this.plaidClient.itemPublicTokenExchange({
        public_token: publicToken,
      });

      const { access_token, item_id } = exchangeResponse.data;

      const accountsResponse = await this.plaidClient.accountsGet({
        access_token,
      });

      const newAccount: Partial<Account> = {
        id: uuidv4(),
        userId,
        plaidAccountId: accountsResponse.data.accounts[0].account_id,
        plaidAccessToken: access_token,
        plaidItemId: item_id,
        name: accountsResponse.data.accounts[0].name,
        officialName: accountsResponse.data.accounts[0].official_name || undefined,
        mask: accountsResponse.data.accounts[0].mask || '',
        type: accountsResponse.data.accounts[0].type as Account['type'],
        subtype: accountsResponse.data.accounts[0].subtype as Account['subtype'],
        balanceCurrent: accountsResponse.data.accounts[0].balances.current ?? 0,
        balanceAvailable: accountsResponse.data.accounts[0].balances.available ?? undefined,
        balanceLimit: accountsResponse.data.accounts[0].balances.limit ?? undefined,
        currency: accountsResponse.data.accounts[0].balances.iso_currency_code || 'USD',
        status: 'active',
        createdAt: new Date(),
        updatedAt: new Date()
      };

      // Insert the new account into the database
      const { data, error } = await this.db.accounts()
        .insert(newAccount);
      
      if (error) {
        console.error('Error creating account in database:', error);
        throw new Error('Failed to save account to database');
      }
      
      // Update the user's plaidItemIds array
      await this.updateUserPlaidItemIds(userId, item_id);
      
      return newAccount as Account;
    } catch (error) {
      console.error('Error exchanging public token:', error);
      throw new Error('Failed to link Plaid account');
    }
  }

  async syncTransactions(account: Account): Promise<{
    added: Transaction[];
    modified: Transaction[];
    removed: string[];
  }> {
    try {
      const response = await this.plaidClient.transactionsSync({
        access_token: account.plaidAccessToken,
        count: 500,
      });

      const addedTransactions: Partial<Transaction>[] = (response.data.added as PlaidTransaction[]).map(plaidTx => ({
        id: uuidv4(),
        user_id: account.userId,
        account_id: account.id,
        plaidTransactionId: plaidTx.transaction_id,
        amount: plaidTx.amount,
        date: plaidTx.date,
        name: plaidTx.name || '',
        merchantName: plaidTx.merchant_name,
        category: plaidTx.category || [],
        categoryId: plaidTx.category_id || '',
        pending: plaidTx.pending,
        paymentChannel: plaidTx.payment_channel as Transaction['paymentChannel'],
        isRecurring: false, // TODO: Implement recurring detection logic
        tags: [],
        location: plaidTx.location ? {
          address: plaidTx.location.address,
          city: plaidTx.location.city,
          region: plaidTx.location.region,
          postalCode: plaidTx.location.postal_code,
          country: plaidTx.location.country,
          lat: plaidTx.location.lat,
          lon: plaidTx.location.lon,
        } : undefined,
        created_at: new Date(),
        updated_at: new Date(),
      }));

      const modifiedTransactions: Partial<Transaction>[] = (response.data.modified as PlaidTransaction[]).map(plaidTx => ({
        id: uuidv4(), // Note: This should match existing transaction ID in production
        user_id: account.userId,
        account_id: account.id,
        plaidTransactionId: plaidTx.transaction_id,
        amount: plaidTx.amount,
        date: plaidTx.date,
        name: plaidTx.name || '',
        merchantName: plaidTx.merchant_name,
        category: plaidTx.category || [],
        categoryId: plaidTx.category_id || '',
        pending: plaidTx.pending,
        paymentChannel: plaidTx.payment_channel as Transaction['paymentChannel'],
        isRecurring: false, // TODO: Implement recurring detection logic
        tags: [],
        location: plaidTx.location ? {
          address: plaidTx.location.address,
          city: plaidTx.location.city,
          region: plaidTx.location.region,
          postalCode: plaidTx.location.postal_code,
          country: plaidTx.location.country,
          lat: plaidTx.location.lat,
          lon: plaidTx.location.lon,
        } : undefined,
        created_at: new Date(),
        updated_at: new Date(),
      }));

      const removedTransactionIds = (response.data.removed as PlaidRemovedTransaction[]).map(
        plaidTx => plaidTx.transaction_id
      );

      // Insert new transactions
      if (addedTransactions.length > 0) {
        const { error: addError } = await this.db.transactions().insert(addedTransactions);
        if (addError) {
          console.error('Error adding transactions:', addError);
          throw new Error('Failed to add transactions');
        }
      }

      // Update modified transactions
      for (const transaction of modifiedTransactions) {
        const { error: updateError } = await this.db.transactions()
          .update(transaction)
          .eq('plaidTransactionId', transaction.plaidTransactionId);
        if (updateError) {
          console.error('Error updating transaction:', updateError);
        }
      }

      // Delete removed transactions
      if (removedTransactionIds.length > 0) {
        const { error: deleteError } = await this.db.transactions()
          .delete()
          .in('plaidTransactionId', removedTransactionIds);
        if (deleteError) {
          console.error('Error deleting transactions:', deleteError);
        }
      }

      return {
        added: addedTransactions as Transaction[],
        modified: modifiedTransactions as Transaction[],
        removed: removedTransactionIds,
      };
    } catch (error) {
      console.error('Error syncing transactions:', error);
      throw new Error('Failed to synchronize transactions');
    }
  }

  async handleWebhook(webhookType: string, webhookCode: string, payload: any): Promise<void> {
    switch (webhookType) {
      case 'TRANSACTIONS':
        if (webhookCode === 'INITIAL_UPDATE' || webhookCode === 'DEFAULT_UPDATE') {
          const { data: accounts, error } = await this.db.accounts()
            .select('*')
            .eq('plaidItemId', payload.item_id);
          
          if (error) {
            console.error('Error finding account by Plaid item ID:', error);
            return;
          }
          
          const account = accounts?.[0];
          if (account) {
            await this.syncTransactions(account);
            
            // Update last synced timestamp
            await this.db.accounts()
              .update({ updatedAt: new Date() })
              .eq('id', account.id);
          }
        }
        break;
      case 'ITEM':
        if (webhookCode === 'ERROR') {
          const { data: accounts, error } = await this.db.accounts()
            .select('*')
            .eq('plaidItemId', payload.item_id);
          
          if (error) {
            console.error('Error finding account by Plaid item ID:', error);
            return;
          }
          
          const account = accounts?.[0];
          if (account) {
            await this.db.accounts()
              .update({
                status: 'error',
                updatedAt: new Date()
              })
              .eq('id', account.id);
              
            // Notify user about the error (in a real app, this would send an email or push notification)
            console.log(`Account ${account.name} has encountered an error: ${payload.error?.error_code}`);
          }
        } else if (webhookCode === 'PENDING_EXPIRATION') {
          // Handle pending expiration by notifying the user
          const { data: accounts } = await this.db.accounts()
            .select('*')
            .eq('plaidItemId', payload.item_id);
            
          const account = accounts?.[0];
          if (account) {
            console.log(`Account ${account.name} credentials are expiring soon. User should re-authenticate.`);
          }
        }
        break;
      default:
        console.warn('Unhandled webhook type:', webhookType);
    }
  }
  
  /**
   * Update a user's plaidItemIds array to include the new item ID
   * @param userId User ID
   * @param itemId Plaid Item ID to add
   */
  private async updateUserPlaidItemIds(userId: string, itemId: string): Promise<void> {
    try {
      // Get the current user
      const { data: user, error: userError } = await this.db.users()
        .select('*')
        .eq('id', userId)
        .single();
      
      if (userError || !user) {
        console.error('Error fetching user:', userError);
        return;
      }
      
      // Add the new item ID to the plaidItemIds array if it's not already there
      if (!user.plaidItemIds.includes(itemId)) {
        await this.db.users()
          .update({ plaidItemIds: [...user.plaidItemIds, itemId], updatedAt: new Date() })
          .eq('id', userId);
      }
    } catch (error) {
      console.error('Error updating user plaidItemIds:', error);
    }
  }
}

export default PlaidService;
