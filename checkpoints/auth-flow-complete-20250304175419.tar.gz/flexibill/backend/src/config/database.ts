import { DataSourceOptions } from 'typeorm';
import { join } from 'path';

const isDevelopment = process.env.NODE_ENV === 'development';

const config: DataSourceOptions = {
  type: 'postgres',
  host: process.env.DB_HOST || 'db',
  port: parseInt(process.env.DB_PORT || '5432', 10),
  username: process.env.DB_USERNAME || 'postgres',
  password: process.env.DB_PASSWORD || 'postgres',
  database: process.env.DB_NAME || 'flexibill',
  entities: [
    join(__dirname, '..', 'entities', '*.entity.{ts,js}')
  ],
  migrations: [
    join(__dirname, '..', 'migrations', '*.{ts,js}')
  ],
  subscribers: [
    join(__dirname, '..', 'subscribers', '*.subscriber.{ts,js}')
  ],
  // Development options
  synchronize: isDevelopment,
  logging: isDevelopment ? ['query', 'error'] : ['error'],
  logger: 'advanced-console',
  maxQueryExecutionTime: 1000, // Log slow queries
  // Production options
  ssl: !isDevelopment ? {
    rejectUnauthorized: false // Needed for some cloud providers
  } : false,
  cache: !isDevelopment ? {
    type: 'redis',
    options: {
      host: process.env.REDIS_HOST || 'redis',
      port: parseInt(process.env.REDIS_PORT || '6379', 10)
    },
    duration: 60000 // Cache for 1 minute
  } : false,
  // Common options
  extra: {
    max: 20, // Connection pool size
    connectionTimeoutMillis: 10000,
    idleTimeoutMillis: 60000
  },
  migrationsRun: true, // Auto-run migrations
  migrationsTableName: 'migrations',
  entityPrefix: '', // Can be used to prefix all tables
  namingStrategy: {
    // Convert camelCase to snake_case for database columns
    columnName: (propertyName: string, customName: string): string => {
      return customName || propertyName.replace(/([A-Z])/g, '_$1').toLowerCase();
    }
  }
};

export default config;