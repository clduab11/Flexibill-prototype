import express, { Request, Response } from 'express';
import PlaidService from '../services/PlaidService';
import { authenticateUser } from '../middleware/authMiddleware';
import { APIResponse } from '../utils/response';
import { DatabaseService } from '../db/DatabaseService';
import { Account } from '../entities/account.entity';

const router = express.Router();
const plaidService = new PlaidService(
  process.env.PLAID_CLIENT_ID || '',
  process.env.PLAID_SECRET || '',
  (process.env.PLAID_ENVIRONMENT as 'sandbox' | 'development' | 'production') || 'sandbox'
);
const db = DatabaseService.getInstance();

/**
 * Create a Plaid Link token
 * Requires user authentication
 */
router.post('/create-link-token', authenticateUser, async (req: Request, res: Response) => {
  try {
    const userId = req.user?.id; // Use optional chaining
    if (!userId) {
      return APIResponse.unauthorized(res, 'User not authenticated');
    }

    const linkToken = await plaidService.createLinkToken(userId);
    return APIResponse.success(res, { linkToken });
  } catch (error) {
    console.error('Error creating link token:', error);
    return APIResponse.internalError(res, 'Failed to create Plaid link token', 'PLAID_LINK_ERROR');
  }
});

/**
 * Exchange public token for access token and link account
 * Requires user authentication
 */
router.post('/exchange-public-token', authenticateUser, async (req: Request, res: Response) => {
  try {
    const { publicToken } = req.body;
    const userId = req.user?.id; // Use optional chaining

    if (!userId) {
      return APIResponse.unauthorized(res, 'User not authenticated');
    }

    if (!publicToken) {
      return APIResponse.badRequest(res, 'Public token is required');
    }

    const account = await plaidService.exchangePublicToken(publicToken, userId);
    return APIResponse.success(res, {
      message: 'Account successfully linked with Plaid',
      account: {
        id: account.id,
        name: account.name,
        institution: account.officialName || 'Unknown Institution',
        type: account.type
      }
    });
  } catch (error) {
    console.error('Error exchanging public token:', error);
    return APIResponse.internalError(res, 'Failed to link account with Plaid', 'PLAID_EXCHANGE_ERROR');
  }
});

/**
 * Get user's linked accounts
 * Requires user authentication
 */
router.get('/accounts', authenticateUser, async (req: Request, res: Response) => {
  try {
    const userId = req.user?.id; // Use optional chaining
    if (!userId) {
      return APIResponse.unauthorized(res, 'User not authenticated');
    }
    
    // Fetch user's accounts from database
    const { data: accounts, error } = await db.accounts()
      .select('*')
      .eq('user_id', userId);
      
    if (error) throw error;
    return APIResponse.success(res, { accounts: accounts || [] });
  } catch (error) {
    console.error('Error fetching accounts:', error);
    return APIResponse.internalError(res, 'Failed to fetch accounts', 'ACCOUNT_FETCH_ERROR');
  }
});

/**
 * Manually trigger transaction sync for an account
 * Requires user authentication
 */
router.post('/sync-transactions', authenticateUser, async (req: Request, res: Response) => {
  try {
    const { accountId } = req.body;
    const userId = req.user?.id; // Use optional chaining

    if (!userId) {
      return APIResponse.unauthorized(res, 'User not authenticated');
    }

    if (!accountId) {
      return APIResponse.badRequest(res, 'Account ID is required');
    }

    // Fetch account from database and verify ownership
    const { data: account, error } = await db.accounts()
      .select('*')
      .eq('id', accountId)
      .single();
      
    if (error) {
      console.error('Error fetching account:', error);
      return APIResponse.notFound(res, 'Account not found');
    }

    if (!account) {
      return APIResponse.notFound(res, 'Account not found');
    }

    // Verify account ownership
    if (account.user_id !== userId) {
      return APIResponse.forbidden(res, 'You do not have permission to access this account');
    }

    const syncResult = await plaidService.syncTransactions(account);
    return APIResponse.success(res, {
      message: 'Transactions synced successfully',
      added: syncResult.added.length,
      modified: syncResult.modified.length,
      removed: syncResult.removed.length,
    });
  } catch (error) {
    console.error('Error syncing transactions:', error);
    return APIResponse.internalError(res, 'Failed to sync transactions', 'TRANSACTION_SYNC_ERROR');
  }
});

/**
 * Webhook endpoint for Plaid events
 * This should be a public endpoint, secured by Plaid's webhook verification
 */
router.post('/webhook', async (req: Request, res: Response) => {
  try {
    const { webhook_type, webhook_code, ...payload } = req.body;

    // Process the webhook
    await plaidService.handleWebhook(webhook_type, webhook_code, payload);

    return APIResponse.success(res, { received: true });
  } catch (error) {
    console.error('Error processing Plaid webhook:', error);
    return APIResponse.internalError(res, 'Failed to process webhook', 'WEBHOOK_ERROR');
  }
});

export default router;